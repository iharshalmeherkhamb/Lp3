#Non-Recursive (Iterative) Approach:
def fibonacci_iterative(n):
    if n <= 1:
        return n
    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
        print("Fibonacci sequence Non-Recursive (Iterative) Approach:",b)
    return b
n = 10
result = fibonacci_iterative(n)
print( result)


#Recursive Approach:

def recur_fibo(n):
   if n <= 1:
       return n
   else:
       return(recur_fibo(n-1) + recur_fibo(n-2))

nterms = 5

# check if the number of terms is valid
if nterms <= 0:
   print("Plese enter a positive integer")
else:
   print("Fibonacci sequence:")
   for i in range(nterms):
       print(recur_fibo(i))
